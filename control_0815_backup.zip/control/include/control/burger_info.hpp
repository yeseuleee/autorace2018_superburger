//turtlebot3 info
#define NAME_OF_ROBOT "turtlebot3"
#define NAME_OF_LASER_SENSOR "hlds_laser_sensor"
#define WHEEL_RADIUS 0.033
#define WHEEL_BASE_LENGTH 0.160//0.287