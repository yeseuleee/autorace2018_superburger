#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <opencv2/highgui/highgui.hpp>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <cv_bridge/cv_bridge.h>
#include <iostream>
#include <lane_detection_func/lane_detection_func.hpp>
#include "sensor_msgs/PointCloud2.h"
#include <pcl_conversions/pcl_conversions.h>
#include <pcl_ros/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/octree/octree_search.h>
#include <pcl/ModelCoefficients.h>
#include <pcl_ros/io/pcd_io.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl_ros/segmentation/sac_segmentation.h>
#include "std_msgs/MultiArrayDimension.h"
#include "std_msgs/MultiArrayLayout.h"
#include "std_msgs/Int32MultiArray.h"
#include "std_msgs/Float32MultiArray.h"
#include "std_msgs/Bool.h"
#include "std_msgs/Int8.h"
#include <time.h>
#include <string>
#include <math.h>

#define COORDI_COUNT 4000
#define CLOCK_PER_SEC 1000
static const std::string OPENCV_WINDOW_VF = "Image by videofile";
static const std::string OPENCV_WINDOW_WC = "Image by webcam";
static int debug;
// 기본 영상, 디버깅 메세지 출력
static int web_cam;
// true -> 웹캠영상 / false -> 비디오파일
static int imshow;
// 이미지 프로세싱 중간 과정 영상 출력
static int track_bar;
// 트랙바 컨트롤
static int time_check;
// ?
static int lable;

static int gazebo;
static int bird_eye_view;
static int auto_shot;
static int auto_record;
static int for_gui;
// 횡단보도 탐지방법 찾기
static const std::string record_name;

static int left_min_interval, left_max_interval;
static int right_min_interval, right_max_interval;
static float right_rotation_y_goal,left_rotation_y_goal;
static float default_x_goal, default_y_goal;

//** trackbar vailable **//
static int y_hmin, y_hmax, y_smin, y_smax, y_vmin, y_vmax;
static int w_hmin, w_hmax, w_smin, w_smax, w_vmin, w_vmax;

static int reset_msg;




typedef pcl::PointCloud<pcl::PointXYZRGB> PointCloud;
double fps = 3;
int control_first = 0;
int fourcc = CV_FOURCC('X','V','I','D'); // codec
bool isColor = true;
cv::Point center_pt_t, center_pt_b;
int center_cali;

cv::VideoWriter video_left;
cv::VideoWriter video_right;
cv::VideoWriter video_main;

static std::string groupName;

lane_detect_algo::vec_mat_t lane_m_vec;

float left_interval, right_interval;
float left_ang_vel, right_ang_vel;
float x_goal_, y_goal_, prev_y_goal_;
float left_theta = 0;
float right_theta = 0;

std::vector<int> right_doubling_vec, left_doubling_vec;
int left_steer_avg = 999, right_steer_avg = 999;
int pre_left_steer_avg = 999, pre_right_steer_avg = 999;
int dynamic_center_x = 0, dynamic_center_y = 0;
using namespace lane_detect_algo;
using namespace std;


class InitImgObjectforROS {

public:
        ros::NodeHandle nh;
        image_transport::ImageTransport it;
        image_transport::Subscriber sub_img;
        ros::Subscriber depth_sub;
        std_msgs::Int32MultiArray coordi_array;
        std_msgs::Float32MultiArray goal_array;
        std_msgs::Bool reset_val;
        ros::Publisher pub = nh.advertise<std_msgs::Int32MultiArray>("/"+groupName+"/lane",100);//Topic publishing at each camera
        ros::Publisher goal_pub = nh.advertise<std_msgs::Float32MultiArray>("/"+groupName+"/pixel_goal",100);
        ros::Publisher ang_vel_pub = nh.advertise<std_msgs::Float32MultiArray>("/"+groupName+"/angular_vel",100);
        ros::Publisher reset_msg_pub = nh.advertise<std_msgs::Bool>("/"+groupName+"/reset_msg",100);
        int imgNum = 0;//for saving img
        int leftlane_turn_value_num = 0, rightlane_turn_value_num = 0;
        std::vector<int> leftlane_turn_value_vec, rightlane_turn_value_vec;
        cv::Mat output_origin_for_copy;//for saving img
        InitImgObjectforROS();
        ~InitImgObjectforROS();
        void depthMessageCallback(const sensor_msgs::PointCloud2::ConstPtr& input);
        void imgCb(const sensor_msgs::ImageConstPtr& img_msg);
        void initParam();
        void initMyHSVTrackbar(const string &trackbar_name);
        void initMyRESETTrackbar(const string &trackbar_name);
        void setMyHSVTrackbarValue(const string &trackbar_name);
        void setMyRESETTrackbarValue(const string &trackbar_name);
        void setColorPreocessing(lane_detect_algo::CalLane callane, cv::Mat src, cv::Mat& dst_y, cv::Mat& dst_w);
        void setProjection(lane_detect_algo::CalLane callane, cv::Mat src, unsigned int* H_aix_Result_color);
        void restoreImgWithLangeMerge(lane_detect_algo::CalLane callane, cv::Mat origin_size_img, cv::Mat src_y, cv::Mat src_w, cv::Mat& dst);
        void extractLanePoint(cv::Mat origin_src, cv::Mat lane_src);
        void initMyHSVTrackbar_old(const string &trackbar_name, int *hmin, int *hmax, int *smin, int *smax, int *vmin, int *vmax);
        void setMyHSVTrackbarValue_old(const string &trackbar_name,int *hmin, int *hmax, int *smin, int *smax, int *vmin, int *vmax);
        void setPixelGoal(double* goal, int num);
        void setMySobelwithROI(cv::Mat src, double delete_row_per, const string &lane_name, cv::Mat& dst);
        void setMyLaneBox(cv::Point t_pt, cv::Point b_pt, const string &lane_name, std::vector<cv::Point> &dst);
        bool setMyLaneFitting(cv::Mat src_img, std::vector<cv::Point> src_pt, const string &lane_name, std::vector<cv::Point> &dst);
        int FittedLaneCheck(std::vector<cv::Point> src, const string &lane_name);
        void setMyCannywithROI(const string &lane_name, cv::Mat &dst);
};



InitImgObjectforROS::InitImgObjectforROS() : it(nh){
        initParam();
        if(!web_cam) {//'DEBUG_SW == TURE' means subscribing videofile image
                sub_img = it.subscribe("/"+groupName+"/videofile/image_raw",1,&InitImgObjectforROS::imgCb,this);
        }
        else{         //'DEBUG_SW == FALSE' means subscribing webcam image
                if(!gazebo){//use webcam topic
                        sub_img = it.subscribe("/"+groupName+"/raw_image",1,&InitImgObjectforROS::imgCb,this);
                        //sub_img = it.subscribe("/camera/depth/points",1,&InitImgObjectforROS::imgCb,this);
                        //depth_sub = nh.subscribe("/camera/depth_registered/points", 1, &InitImgObjectforROS::depthMessageCallback, this);
                }
                else{//use gazebo topic
                        sub_img = it.subscribe("/camera/image",1,&InitImgObjectforROS::imgCb,this);
                }
                
                
               
        }

        if(track_bar) {
                initMyHSVTrackbar(groupName+"_YELLOW_TRACKBAR");
                initMyHSVTrackbar(groupName+"_WHITE_TRACKBAR");
                initMyRESETTrackbar("reset msg");
        }
}


InitImgObjectforROS::~InitImgObjectforROS(){
        if(debug) {//'DEBUG_SW == TURE' means subscribing videofile image
                cv::destroyWindow(OPENCV_WINDOW_VF);
        }
        else{     //'DEBUG_SW == FALE' means subscribing webcam image
                cv::destroyWindow(OPENCV_WINDOW_WC);
        }
}
void InitImgObjectforROS::depthMessageCallback(const sensor_msgs::PointCloud2::ConstPtr& input)
{
      // input.x;
//      pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZRGB>);
//      pcl::fromROSMsg (*input, *cloud);
//      cloud.resize(320,240);
//      cv::Mat imageFrame;
//      if (cloud->isOrganized()) {
//         imageFrame = cv::Mat(cloud->height, cloud->width, CV_8UC3); 

//         for (int h=0; h<imageFrame.rows; h++) {
//             for (int w=0; w<imageFrame.cols; w++) {

//                 pcl::PointXYZRGB point = cloud->at(w, h);

//                 Eigen::Vector3i rgb = point.getRGBVector3i();

//                 imageFrame.at<cv::Vec3b>(h,w)[0] = rgb[2];
//                 imageFrame.at<cv::Vec3b>(h,w)[1] = rgb[1];
//                 imageFrame.at<cv::Vec3b>(h,w)[2] = rgb[0];
                
//                 //int i = centre_x + centre_y*cloud->width;
//                 //depth[call_count] = (float)cloud->points[i].z;

//             }
//          }
//          cv::imshow("aaaaa",imageFrame);
//      }
}


void InitImgObjectforROS::imgCb(const sensor_msgs::ImageConstPtr& img_msg){
        cv_bridge::CvImagePtr cv_ptr;
        cv::Mat frame, yellow_hsv, white_hsv, yellow_labeling,white_labeling, laneColor, origin, mergelane, rec_img;
        std::vector<cv::Point> box_pt_y,box_pt_w;
        cv::Point left_slope, right_slope;
        uint frame_height, frame_width;
        bool is_left_box_true = false, is_right_box_true = false;        
        try{
                cv_ptr = cv_bridge::toCvCopy(img_msg,sensor_msgs::image_encodings::BGR8);
                frame = cv_ptr->image;
                origin = cv_ptr->image;
                rec_img = cv_ptr->image;
                if(!frame.empty()) {
                        if(!gazebo){//if you use gazebo topic than this condition not used.
                                cv::resize(origin,frame,cv::Size(origin.cols/2,origin.rows/2),0,0,CV_INTER_AREA);//img downsizing //320 240
                        }
                        if(auto_record){
                                if(groupName == "left")
                                        video_left << frame;
                                else if(groupName == "right")
                                        video_right << frame;
                                else if(groupName == "main")
                                        video_main << frame;        
                        }                   
                        
                        /*another solution->*/ //cv::resize(frame, frame, cv::Size(), 0.2, 0.2 320 240);
                        frame_height = (uint)frame.rows;
                        frame_width = (uint)frame.cols;
                        

                        lane_detect_algo::CalLane callane;

                        ////*Testing histogram*////탑뷰 아니면 쓰기 힘들다..
                        // unsigned int* H_yResultYellow = new unsigned int[frame_width];
                        // std::memset(H_yResultYellow, 0, sizeof(uint) * frame_width);
                        // unsigned int* H_yResultWhite = new unsigned int[frame_width];
                        // std::memset(H_yResultWhite, 0, sizeof(uint) * frame_width);
                        // unsigned int* H_xResultYellow = new unsigned int[frame_height];
                        // std::memset(H_xResultYellow, 0, sizeof(uint) * frame_height);
                        // unsigned int* H_xResultWhite = new unsigned int[frame_height];
                        // std::memset(H_xResultWhite, 0, sizeof(uint) * frame_height);
                        //setProjection(callane, yellow_hsv, H_yResultWhite);
                        
                        ///////*reset trackbar set*//////////////////
                        
                        if(track_bar){
                                cv::Mat reset_img = cv::Mat::zeros(frame.size(), CV_8UC3);
                                setMyRESETTrackbarValue("reset msg");
                                cv::imshow("reset msg",reset_img);
                                reset_val.data = reset_msg;
                        }
                        
                        ////*Process color detection including trackbar setting*////
                        //컬러영상에 소벨엣지 적용해서 노란색 추출하는방법 생각해보기
                        
                        //setColorPreocessing(callane, sobel_v, yellow_hsv, white_hsv);
                        setColorPreocessing(callane, frame, yellow_hsv, white_hsv);
                        //cv::Mat yellow_sobel;
                        //setMySobelwithROI(frame,0.2,"left",yellow_sobel);
                        cv::Mat yellow_canny = frame.clone();
                        setMyCannywithROI("left",yellow_canny);
                        cv::Mat white_sobel;
                        setMySobelwithROI(frame,0.2,"right",white_sobel);
                        
                        
                        cv::Mat gui_img = frame.clone();
                        cv::Point left_roi_t(10,frame.rows/2);
                        cv::Point left_roi_b(frame.cols/2,frame.rows-1);
                        cv::Point right_roi_t(frame.cols/2,frame.rows/2);
                        cv::Point right_roi_b(frame.cols-1,frame.rows-1);
                        int yellow_valid, white_valid;
                        

                        //yellow_valid = callane.makeContoursLeftLane(yellow_hsv, yellow_labeling);//source img channel should be 1
                        //int w_valid = callane.makeContoursLeftLane(white_hsv,yellow_labeling);
                       // int y_valid = callane.makeContoursLeftLane(yellow_sobel, yellow_labeling);
                        //cv::Mat no_label_y = yellow_sobel.clone();
                        //cv::Mat yes_label_y = yellow_sobel.clone();
                        //callane.makeContoursLeftLane(yellow_sobel,yes_label_y);
                        //cv::imshow("no label y",no_label_y);
                       // cv::imshow("yes label y",yes_label_y);
                       // if(w_valid != -1)
                       // std::cout<<"@@@@@@@@@@@@@@@@@@@@@@@@w_valid : "<<w_valid<<std::endl;
                        //if(y_valid < 1)
                        //std::cout<<"########################y_valid : "<<y_valid<<std::endl;
                        box_pt_y.push_back(left_roi_t);
                        box_pt_y.push_back(left_roi_b);
                        yellow_labeling = yellow_canny.clone();
                        // cv::imshow("?",yellow_labeling);
                        // for(int y = yellow_labeling.rows/2; y<yellow_labeling.rows; y++){
                        //         uchar* none_roi_data = yellow_labeling.ptr<uchar>(y);
                        //         for(int x = 0; x<11; x++){
                        //                 if(none_roi_data[x] != (uchar)0){
                        //                         none_roi_data[x] = (uchar)0;
                        //                 }
                        //         }
                        // }
                        // cv::imshow("??",yellow_labeling);
                        // if(yellow_valid == -1){
                        //         int yellow_lane_check = 0; //이게 일정값보다 작으면 선이아예안들어온거구 아니면 빛반사땜시 못잡은거
                        //         for(int y = 0; y<yellow_hsv.rows/2; y++){
                        //                 uchar* none_roi_data = yellow_hsv.ptr<uchar>(y);
                        //                 for(int x = 0; x < yellow_hsv.cols/2; x++){
                        //                         if(none_roi_data[x] != (uchar)0){
                        //                                 yellow_lane_check++;
                        //                         }
                        //                 }
                        //         }
                        //         if(yellow_lane_check < 30){ //흰색선 roi에 흰색은 없고 노란선 roi의 노란색은 흰색으로 보인 경우 sobel
                        //                 int white_lane_check = 0;
                        //                 for(int y = 0; y<white_hsv.rows/2; y++){
                        //                         uchar* none_roi_data = white_hsv.ptr<uchar>(y);
                        //                         for(int x = white_hsv.cols/2; x < white_hsv.cols-1; x++){
                        //                                 if(none_roi_data[x] != (uchar)0){
                        //                                         white_lane_check++;
                        //                                 }
                        //                         }
                        //                 }
                        //                 if(white_lane_check<30){
                        //                         yellow_labeling = yellow_sobel.clone();
                        //                         yellow_valid = 1;
                        //                 }
                        //         }
                        // }
                        box_pt_w.push_back(cv::Point(frame.cols/2, frame.rows/2));
                        box_pt_w.push_back(cv::Point(frame.cols-1,frame.rows-1));
                        
                        white_valid = callane.makeContoursRightLane(white_hsv, white_labeling);

                        center_pt_t = cv::Point(frame_width/2,0);
                        center_pt_b = cv::Point(frame_width/2,frame_height-1);

                        //**If you use vector type variable, Please cheack your variable is not empty! 
                        bool left_point = false, right_point = false;
                        std::vector<cv::Point> left_lane_fitting, right_lane_fitting, dot_lane_fitting;  
                        int left_lane_turn, right_lane_turn, dot_lane_turn;
                        //if(!box_pt_y.empty() || !box_pt_w.empty()){
                        //**left roi editted if that needed
                        //if(yellow_valid != -1){
                               // setMyLaneBox(left_roi_t, left_roi_b, "left", box_pt_y);
                                //*for inner left lane fitting*//
                                if(setMyLaneFitting(yellow_labeling, box_pt_y, "left", left_lane_fitting)){
                                       // left_interval = center_pt_b.x - left_lane_fitting[10].x;                       
                                       left_lane_turn = FittedLaneCheck(left_lane_fitting,"left");
                                       if(left_lane_turn != 3){
                                               leftlane_turn_value_num++;
                                       }
                                       
                                       leftlane_turn_value_vec.push_back(left_lane_turn);
                                }
                                else{
                                        yellow_labeling = cv::Mat::zeros(yellow_labeling.size(), CV_8UC3);
                                        if(debug) std::cout<<"invalid left lane"<<std::endl;
                                }  
                        //}
                        // else{
                        //         if(debug) std::cout<<"invaild left label"<<std::endl;
                        // }

                        if(white_valid != -1){
                              //  setMyLaneBox(right_roi_t, right_roi_b, "right", box_pt_w);
                                //*for inner right lane fitting*// 
                                if(setMyLaneFitting(white_labeling, box_pt_w, "right", right_lane_fitting)){
                                        //right_interval = right_lane_fitting[10].x - center_pt_b.x;
                                        right_lane_turn = FittedLaneCheck(right_lane_fitting,"right");
                                        if(right_lane_turn != 3){
                                                rightlane_turn_value_num++;
                                        }
                                        
                                        rightlane_turn_value_vec.push_back(right_lane_turn);
                                }
                                else{
                                       white_labeling = cv::Mat::zeros(white_labeling.size(), CV_8UC3);
                                       if(debug) std::cout<<"invaild right lane"<<std::endl;
                                }
                                std::vector<cv::Point> dot_test_box_pt_w;
                                dot_test_box_pt_w.push_back(cv::Point(frame.cols/2,frame.rows/2));
                                dot_test_box_pt_w.push_back(cv::Point(frame.cols-1,frame.rows-1));
                                if(setMyLaneFitting(white_hsv,dot_test_box_pt_w, "dot_test", dot_lane_fitting)){
                                        dot_lane_turn = FittedLaneCheck(dot_lane_fitting,"dot_test");
                                }//도트는 선 따로 피팅하자~~
                                else{
                                      white_labeling = cv::Mat::zeros(white_labeling.size(), CV_8UC3);  
                                      if(debug) std::cout<<"invaild right label"<<std::endl;
                                }
                        }
                        ///////**param goal test/////
                        // bool param_state;
                        // nh.setParam("/control/wait",true);
                        // nh.getParam("/control/wait",param_state);
                        // setPixelGoal(test,test_num);
                        
                        
                        goal_array.data.clear();
                        goal_array.data.resize(0);
                        int straight_score = 0,l_score = 0, r_score = 0;//select score num 0,-1,1,3
                        int max = -9999, score_select = -9999;
                        int left_steer = 0, right_steer = 0;
                        float left_doubling_val = 0, right_doubling_val = 0;
                        int center_y_start = 10;
                        int fit_lane_end;
                        int left_lane_pick_num = 0, right_lane_pick_num = 0;
                        
                        if(rightlane_turn_value_num == 10 || leftlane_turn_value_num == 10){
                                
                                // if(!right_doubling_vec.empty()){
                                //         int doubling_sum = 0;
                                //         for(int i = 0; i< right_doubling_vec.size(); i++){
                                //                 doubling_sum += right_doubling_vec[i];
                                //         }
                                //         right_steer_avg = doubling_sum/right_doubling_vec.size();
                                // }
                                // if(!left_doubling_vec.empty()){
                                //         int doubling_sum = 0;
                                //         for(int i = 0; i< left_doubling_vec.size(); i++){
                                //                 doubling_sum += left_doubling_vec[i];
                                //         }
                                //         left_steer_avg = doubling_sum/left_doubling_vec.size();
                                // }
                                // if(!right_lane_fitting.empty() && !left_lane_fitting.empty()){
                                        
                                //         if(rightlane_turn_value_vec.size() >= leftlane_turn_value_vec.size()){
                                //             for(int i = 0; i < rightlane_turn_value_vec.size(); i++){
                                //                 if(rightlane_turn_value_vec[i] == 0) straight_score++;
                                //                 else if(rightlane_turn_value_vec[i] > 0) r_score++;
                                //                 else if(rightlane_turn_value_vec[i] < 0) l_score++;
                                //                 }    
                                //         }
                                //         else{
                                //             for(int i = 0; i < leftlane_turn_value_vec.size(); i++){
                                //                 if(leftlane_turn_value_vec[i] == 0 ) straight_score++;
                                //                 else if(leftlane_turn_value_vec[i] > 0) r_score++;
                                //                 else if(leftlane_turn_value_vec[i] < 0) l_score++;
                                //                 }    
                                //         }
                                        
                                        
                                // }
                                // else if(!right_lane_fitting.empty()){//left lane fitting is empty
                                //         for(int i = 0; i < rightlane_turn_value_vec.size(); i++){
                                //                 if(rightlane_turn_value_vec[i]  == 0) straight_score++;
                                //                 else if(rightlane_turn_value_vec[i] > 0) r_score++;
                                //                 else if(rightlane_turn_value_vec[i] < 0) l_score++;
                                //         }
                                        

                                // }
                                // else{
                                //         for(int i = 0; i < leftlane_turn_value_vec.size(); i++){
                                //                 if(leftlane_turn_value_vec[i]  == 0) straight_score++;
                                //                 else if(leftlane_turn_value_vec[i] > 0) r_score++;
                                //                 else if(leftlane_turn_value_vec[i] < 0) l_score++;
                                //         }
                                       
                                // }

                                // if(max<straight_score){
                                //         max = straight_score;
                                //         score_select = 0;
                                // }
                                // if(max<l_score){
                                //         max = l_score;
                                //         score_select = -1;
                                // }
                                // if(max<r_score){
                                //         max = r_score;
                                //         score_select = 1;
                                // }
                                // switch (score_select)
                                // {
                                //         case 0://직진주행
                                //                 left_steer = 0;
                                //                 right_steer = 0;
                                //                // std::cout<<"go straght"<<std::endl;
                                //                 break;
                                //         case -1://우회전
                                //                 left_steer = 1;
                                //                 right_steer = 0;
                                //                 //std::cout<<"turn left"<<std::endl;
                                //                 break;
                                //         case 1:
                                //                 left_steer = 0;
                                //                 right_steer = 1;
                                                
                                //                 break;
                                // }
                                // if(pre_left_steer_avg != 999 && !left_doubling_vec.empty()){
                                        
                                //         if(abs(pre_left_steer_avg - left_steer_avg) >= 10 && abs(pre_left_steer_avg - left_steer_avg) < 20){
                                //                 left_doubling_val = 0.015;
                                //         }
                                //         else if(abs(pre_left_steer_avg - left_steer_avg) >= 20 && abs(pre_left_steer_avg - left_steer_avg) < 30){
                                //                 left_doubling_val = 0.035;
                                //         }
                                // }
                                // pre_left_steer_avg = left_steer_avg;
                                // if(pre_right_steer_avg != 999 && !right_doubling_vec.empty()){
                                //         if(abs(pre_right_steer_avg - right_steer_avg) >= 10 && abs(pre_right_steer_avg - right_steer_avg) < 20){
                                //                 right_doubling_val = 0.015;
                                //         }
                                //         else if(abs(pre_right_steer_avg - right_steer_avg) >= 20 && abs(pre_right_steer_avg - right_steer_avg) < 30){
                                //                 right_doubling_val = 0.035;
                                //         }
                                // } 
                                // pre_right_steer_avg = right_steer_avg;

                                left_doubling_vec.clear();
                                right_doubling_vec.clear();
                                left_doubling_vec.resize(0);
                                right_doubling_vec.resize(0);
                                std::cout<<"right doubling : "<<right_doubling_val<<std::endl;
                                std::cout<<"left doubleing : "<<left_doubling_val<<std::endl;
                               // std::cout<<"right : "<<right_lane_fitting<<std::endl;
                                 //std::cout<<"left : "<<left_lane_fitting<<std::endl;
                                if(!right_lane_fitting.empty() && left_lane_fitting.empty()){
                                        int left_fit_size = 0, right_fit_size = 0;
                                        left_fit_size = left_lane_fitting.size();
                                        right_fit_size = right_lane_fitting.size();
                                        if(left_fit_size > 30 && right_fit_size >30){
                                                if(left_fit_size >= right_fit_size){
                                                        fit_lane_end = right_fit_size;
                                                }
                                                else{
                                                        fit_lane_end = left_fit_size;
                                                }
                                                if(abs(left_lane_fitting[center_y_start].y - right_lane_fitting[center_y_start].y) > 10){
                                                        int j = center_y_start, k = center_y_start;
                                                        if(left_lane_fitting[center_y_start].y > right_lane_fitting[center_y_start].y){//작은값이 영상에서 더 위에 있는 값
                                                                for(int i = center_y_start; i < fit_lane_end; i++){
                                                                        if(abs(left_lane_fitting[i].y - right_lane_fitting[k].y) <= 10){
                                                                                j = i;
                                                                                left_lane_pick_num = i;
                                                                                right_lane_pick_num = k;
                                                                                break;
                                                                        }
                                                                        if(left_lane_fitting[i].y < right_lane_fitting[k].y){
                                                                                k++;
                                                                        }
                                                                }
                                                        }
                                                        else if(left_lane_fitting[center_y_start].y < right_lane_fitting[center_y_start].y){
                                                                for(int i = center_y_start; i < fit_lane_end; i++){
                                                                        if(abs(right_lane_fitting[i].y - left_lane_fitting[k].y) <= 10){
                                                                                j = i;
                                                                                left_lane_pick_num = k;
                                                                                right_lane_pick_num = i;
                                                                                break;
                                                                        }
                                                                        if(right_lane_fitting[i].y < left_lane_fitting[k].y){
                                                                                k++;
                                                                        }
                                                                }
                                                        }
                                                        dynamic_center_y = frame.rows/2; 
                                                        if(j != center_y_start){
                                                                //cv::line(gui_img,left_lane_fitting[left_lane_pick_num],right_lane_fitting[right_lane_pick_num],cv::Scalar(20,100,30),2);
                                                                dynamic_center_x = (left_lane_fitting[left_lane_pick_num].x + right_lane_fitting[right_lane_pick_num].x)/2;
                                                                std::cout<<"1"<<std::endl;
                                                        }
                                                        else{
                                                                left_lane_pick_num = center_y_start;
                                                                right_lane_pick_num = center_y_start;
                                                                //cv::line(gui_img,left_lane_fitting[left_lane_pick_num],right_lane_fitting[right_lane_pick_num],cv::Scalar(20,100,30),2);
                                                                dynamic_center_x = (left_lane_fitting[left_lane_pick_num].x + right_lane_fitting[right_lane_pick_num].x)/2; 
                                                                std::cout<<"2"<<std::endl;
                                                        }
                                                }
                                                else{
                                                        left_lane_pick_num = center_y_start;
                                                        right_lane_pick_num = center_y_start;
                                                        //cv::line(gui_img,left_lane_fitting[center_y_start],right_lane_fitting[center_y_start],cv::Scalar(20,100,30),2);
                                                        dynamic_center_x = (left_lane_fitting[center_y_start].x + right_lane_fitting[center_y_start].x)/2;
                                                        dynamic_center_y = frame.rows/2; 
                                                        std::cout<<"3"<<std::endl;
                                                        //cv::line(gui_img,cv::Point(dynamic_center_x,30),cv::Point(dynamic_center_x,200),cv::Scalar(100,200,23),2); 
                                                }
                                                        

                                        }
                                        else{//한쪽선만
                                                if(left_fit_size > 40){
                                                        left_lane_pick_num = center_y_start;
                                                        right_lane_pick_num = -1;
                                                        dynamic_center_x = frame.cols/2;
                                                        dynamic_center_y = frame.rows/2;
                                                        std::cout<<"4"<<std::endl;
                                                        //cv::line(gui_img,left_lane_fitting[center_y_start],cv::Point(frame.cols/2,left_lane_fitting[center_y_start].y),cv::Scalar(20,100,30),2);
                                                } 
                                                else{
                                                        left_lane_pick_num = -1;
                                                        right_lane_pick_num = center_y_start;
                                                        dynamic_center_x = frame.cols/2;
                                                        dynamic_center_y = frame.rows/2;
                                                        std::cout<<"5"<<std::endl;
                                                        //cv::line(gui_img,right_lane_fitting[center_y_start],cv::Point(frame.cols/2,right_lane_fitting[center_y_start].y),cv::Scalar(20,100,30),2);
                                                }
                                        }
                                        
                                }
                                else if(!left_lane_fitting.empty() && right_lane_fitting.empty()){
                                        left_lane_pick_num = center_y_start;
                                        right_lane_pick_num = -1;
                                        dynamic_center_x = frame.cols/2;
                                        dynamic_center_y = frame.rows/2;       
                                        std::cout<<"6"<<std::endl;
                                }
                                else if(left_lane_fitting.empty() && !right_lane_fitting.empty()){
                                        left_lane_pick_num = -1;
                                        right_lane_pick_num = center_y_start;
                                        dynamic_center_x = frame.cols/2;
                                        dynamic_center_y = frame.rows/2;    
                                        std::cout<<"7"<<std::endl;  
                                }
                                if(!left_lane_fitting.empty()){
                                        left_interval = abs(dynamic_center_x - left_lane_fitting[left_lane_pick_num].x);
                                }
                                else{
                                        left_interval = -1;
                                }
                                if(!right_lane_fitting.empty()){
                                        right_interval = abs(dynamic_center_x - right_lane_fitting[right_lane_pick_num].x);
                                }
                                else{
                                        right_interval = -1;
                                }
                                
                                
                                switch (score_select)
                                {
                                        case 0://직진주행
                                                left_steer = 0;
                                                right_steer = 0;
                                                break;
                                        case -1://좌회전
                                                
                                                break;
                                        case 1://우회전
                                                
                                                break;
                                }

                                
                                goal_array.data.push_back(x_goal_);//linear_vel아님 정확힌 직진방향 x목표점임. 속도변수따로만들기
                                goal_array.data.push_back(y_goal_);
                                prev_y_goal_ = y_goal_;
                                if(rightlane_turn_value_num == 10) rightlane_turn_value_num = 0;
                                if(leftlane_turn_value_num == 10) leftlane_turn_value_num = 0;
                        }
                       // cv::line(gui_img, cv::Point(dynamic_center_x,dynamic_center_y), cv::Point(dynamic_center_x,dynamic_center_y+100),cv::Scalar(100,40,200),2);
                        cv::imshow("gui",gui_img);
                        //std::cout<<"left_interval : "<<left_interval<<", right_interval : "<<right_interval<<std::endl;       
                        // if(is_left_box_true && !is_right_box_true){//tracking left lane(yellow lane)
                        //         if(left_interval > left_min_interval && left_interval < left_max_interval){//go straight condition
                        //                 y_goal_ = 0;        
                        //         }
                                
                        //                 //** left lane tracking condition
                        //                 if(left_interval <= left_min_interval){//need right rotation(ang_vel<0 : right rotation)
                        //                         // if(left_interval >1000) y_goal_ = -0.04;
                        //                         // else y_goal_ = -0.01;
                        //                         y_goal_ = -0.01;
                        //                         //y_goal_ = abs(left_theta);
                        //                 }
                        //                 else{//need left rotation(ang_vel>0 : left rotation)
                        //                         // if(left_interval <0) y_goal_ = 0.04;
                        //                         // else y_goal_ = 0.01;
                        //                         y_goal_ = 0.01;
                                                
                        //                 }

                                
                        // }
                        // else if(is_right_box_true && !is_left_box_true){//tracking right lane(white lane)
                        //         float right_degree = right_theta*180/CV_PI;
                        //         float left_degree = left_theta*180/CV_PI;
                        //         float sum_degree = right_degree + left_degree;
                        //         if(right_interval > right_min_interval && right_interval < right_max_interval){//go straight condition
                                        
                        //                 y_goal_ = 0;        
                        //         }
          
                        //                 //** right lane tracking condition
                        //                 if(right_interval <= right_min_interval){//need left rotation(ang_vel>0 : left rotation)
                        //                         // if(right_interval <0) y_goal_ = 0.04;
                        //                         // else y_goal_ = 0.01;
                        //                         y_goal_ = 0.01;
                        //                 }
                        //                 else{//need right rotation(ang_vel<0 : right rotation)
                        //                         // if(right_interval >1000) y_goal_ = -0.04;
                        //                         // else y_goal_ = -0.01;
                        //                         y_goal_  = -0.01;
                        //                 }

                        // }
                        // else if(is_left_box_true && is_right_box_true){
                        //         float tmp = -99;
                        //         //if all lane(yellow and white) detected, turtlebot following white lane path tracking
                        //         if(right_interval > right_min_interval && right_interval < right_max_interval){//go straight condition
                        //                 y_goal_ = 0;        
                        //         }
                        //         else{
                        //                 if(right_interval <= right_min_interval){//need left rotation(ang_vel>0 : left rotation)
                        //                         // if(right_interval <0) y_goal_ = 0.04;
                        //                         // else y_goal_ = 0.01;
                        //                         y_goal_ = 0.01;
                        //                         tmp = y_goal_;
                        //                 }
                        //                 else{//need right rotation(ang_vel<0 : right rotation)
                        //                         // if(right_interval >1000) y_goal_ = -0.04;
                        //                         // else y_goal_ = -0.01;
                        //                         y_goal_ = -0.01;
                        //                         tmp = y_goal_;
                        //                 }
                        //         }
                        //         //x_goal_ = 0.1;//직진주행시 가속
                        //         if(left_interval > left_min_interval && left_interval < left_max_interval){//go straight condition
                        //                 y_goal_ = 0;        
                        //         }
                        //         //else if(left_interval + 20 > 50 && left_interval - 20 < 60){//중앙보다 차선쪽에 가까운경우
                        //                 //** left lane tracking condition
                        //                 if(left_interval <= left_min_interval){//need right rotation(ang_vel<0 : right rotation)
                        //                         // if(left_interval >1000) y_goal_ = -0.04;
                        //                         // else y_goal_ = -0.01;
                        //                         y_goal_ = -0.01;
                        //                         tmp = y_goal_;
                                        
                        //                         //y_goal_ = abs(left_theta);
                        //                 }
                        //                 else{//need left rotation(ang_vel>0 : left rotation)
                        //                         // if(left_interval <0) y_goal_ = 0.04;
                        //                         // else y_goal_ = 0.01;
                        //                         y_goal_ = 0.01;
                        //                         tmp = y_goal_;
                        //                         //y_goal_ = abs(left_theta);
                        //                 }


                        // }
                        // else{//if detected no lane, than go straight
                        //         if(prev_y_goal_ < 0){
                        //                 x_goal_ = 0;//.08;
                        //                 y_goal_ = 0.045;
                        //         }
                        //         else if(prev_y_goal_ > 0){
                        //                 x_goal_ = 0;//.08;
                        //                 y_goal_ = -0.045 ;
                        //         }
                        //         else{
                        //                 x_goal_ = 0;
                        //                 y_goal_ = 0;
                        //         }
                                
                                
                        // }

                        // goal_array.data.clear();
                        // goal_array.data.resize(0);
                        // x_goal_ = 0;//.08;

                        // y_goal_ = 0.045 ;
                        // goal_array.data.push_back(x_goal_);//linear_vel아님 정확힌 직진방향 x목표점임. 속도변수따로만들기
                        // goal_array.data.push_back(y_goal_);
                        // prev_y_goal_ = y_goal_;
                       // std::cout<<"linear_vel"<<x_goal_<<std::endl;
                       // std::cout<<"ang_vel"<<y_goal_<<std::endl;
                      
                        
                        
                        ////*Restore birdeyeview img to origin view*////
                        restoreImgWithLangeMerge(callane,frame,yellow_labeling,white_labeling,mergelane);
                        
                        ////*Make lane infomation msg for translate scan data*////
                        extractLanePoint(origin,mergelane);

                        output_origin_for_copy = origin.clone();
                        is_left_box_true = false;
                        is_right_box_true = false;
                        left_point = false;
                        right_point = false;
                        left_interval = 0;
                        right_interval = 0;
                        left_theta = 0;
                        right_theta = 0;
                        // if(is_left_box_true && is_right_box_true){
                        //         center_cali = abs(left_lane_fitting[20].x - right_lane_fitting[20].x)/2;
                        // }
                        // else if(is_left_box_true){
                        //         center_cali = left_lane_fitting[20].x + 50;
                        // }
                        // else{
                        //         center_cali = right_lane_fitting[20].x - 50;
                        // }
                        
                }
                else{//frame is empty
                        while(frame.empty()) {//for unplugged camera
                                cv_ptr = cv_bridge::toCvCopy(img_msg,sensor_msgs::image_encodings::BGR8);
                                frame = cv_ptr->image;
                        }
                        x_goal_ = 0;
                        y_goal_ = 0.;//제자리회전시켜보기
                        center_cali = -1;
                }
        }
        catch(cv_bridge::Exception& e) {
                ROS_ERROR("cv_bridge exception : %s", e.what());
                return;
        }

        if(auto_shot){
                std::cout<<"Save screen shot"<<std::endl;
                cv::imwrite("/home/seuleee/Desktop/autorace_img_src/0721/sign_signal/"+to_string(imgNum)+".jpg", output_origin_for_copy);
                imgNum++;
        }
        int ckey = cv::waitKey(10);
        if(ckey == 27) exit(1);
        else if(ckey == 32){//For save using space key
                std::cout<<"Save screen shot"<<std::endl;
                cv::imwrite("/home/seuleee/Desktop/autorace_img_src/"+to_string(imgNum)+".jpg", output_origin_for_copy);
                imgNum++;
        }
}

void InitImgObjectforROS::initParam(){
        nh.param<int>("/"+groupName+"/lane_detection/debug", debug, 0);
        nh.param<int>("/"+groupName+"/lane_detection/web_cam", web_cam, 0);
        nh.param<int>("/"+groupName+"/lane_detection/imshow", imshow, 0);
        nh.param<int>("/"+groupName+"/lane_detection/track_bar", track_bar, 0);
        nh.param<int>("/"+groupName+"/lane_detection/time_check", time_check, 0);
        nh.param<int>("/"+groupName+"/lane_detection/lable", lable, 0);
        nh.param<int>("/"+groupName+"/lane_detection/gazebo", gazebo, 1);
        nh.param<int>("/"+groupName+"/lane_detection/bird_eye_view", bird_eye_view, 0);
        nh.param<int>("/"+groupName+"/lane_detection/auto_shot", auto_shot, 0);
        nh.param<int>("/"+groupName+"/lane_detection/auto_record", auto_record, 0);
        
        nh.param<int>("/"+groupName+"/lane_detection/left_min_interval",left_min_interval,110);
        nh.param<int>("/"+groupName+"/lane_detection/left_max_interval",left_max_interval,150);
        nh.param<int>("/"+groupName+"/lane_detection/right_min_interval",right_min_interval,120);
        nh.param<int>("/"+groupName+"/lane_detection/right_max_interval",right_max_interval,160);
        nh.param<float>("/"+groupName+"/lane_detection/right_rotation_y_goal",right_rotation_y_goal,-0.1);
        nh.param<float>("/"+groupName+"/lane_detection/left_rotation_y_goal",left_rotation_y_goal,0.1);
        nh.param<float>("/"+groupName+"/lane_detection/default_x_goal",default_x_goal,0.05);
        nh.param<float>("/"+groupName+"/lane_detection/default_y_goal",default_y_goal,0);

        nh.param<int>("/"+groupName+"/lane_detection/reset_msg",reset_msg,0);

        nh.param<int>("/"+groupName+"/lane_detection/y_hmin",y_hmin,15);
        nh.param<int>("/"+groupName+"/lane_detection/y_hmax",y_hmax,21);
        nh.param<int>("/"+groupName+"/lane_detection/y_smin",y_smin,52);
        nh.param<int>("/"+groupName+"/lane_detection/y_smax",y_smax,151);
        nh.param<int>("/"+groupName+"/lane_detection/y_vmin",y_vmin,0);
        nh.param<int>("/"+groupName+"/lane_detection/y_vmax",y_vmax,180);
        nh.param<int>("/"+groupName+"/lane_detection/w_hmin",w_hmin,0);
        nh.param<int>("/"+groupName+"/lane_detection/w_hmax",w_hmax,180);
        nh.param<int>("/"+groupName+"/lane_detection/w_smin",w_smin,0);
        nh.param<int>("/"+groupName+"/lane_detection/w_smax",w_smax,24);
        nh.param<int>("/"+groupName+"/lane_detection/w_vmin",w_vmin,172);
        nh.param<int>("/"+groupName+"/lane_detection/w_vmax",w_vmax,255);
        ROS_INFO("lane_detection %d %d %d %d %d %d %d", debug, web_cam, imshow, track_bar, time_check, lable, gazebo);
        ROS_INFO("imshow %d", imshow);
}

void InitImgObjectforROS::initMyRESETTrackbar(const string &trackbar_name){
        cv::namedWindow(trackbar_name,cv::WINDOW_AUTOSIZE);
        cv::createTrackbar("reset msg",trackbar_name, &reset_msg, 1, NULL);
        cv::setTrackbarPos("reset msg",trackbar_name, reset_msg);
}
void InitImgObjectforROS::setMyRESETTrackbarValue(const string &trackbar_name){
        reset_msg = cv::getTrackbarPos("reset msg",trackbar_name);
        nh.setParam("/"+groupName+"/lane_detection/reset_msg",reset_msg);
}

void InitImgObjectforROS::initMyHSVTrackbar(const string &trackbar_name){
                
                cv::namedWindow(trackbar_name, cv::WINDOW_AUTOSIZE);
                if (trackbar_name.find("YELLOW") != string::npos) { 

                        cv::createTrackbar("h min", trackbar_name, &y_hmin, 179, NULL);
                        cv::setTrackbarPos("h min", trackbar_name, y_hmin);

                        cv::createTrackbar("h max", trackbar_name, &y_hmax, 179, NULL);
                        cv::setTrackbarPos("h max", trackbar_name, y_hmax);

                        cv::createTrackbar("s min", trackbar_name, &y_smin, 255, NULL);
                        cv::setTrackbarPos("s min", trackbar_name, y_smin);

                        cv::createTrackbar("s max", trackbar_name, &y_smax, 255, NULL);
                        cv::setTrackbarPos("s max", trackbar_name, y_smax);

                        cv::createTrackbar("v min", trackbar_name, &y_vmin, 255, NULL);
                        cv::setTrackbarPos("v min", trackbar_name, y_vmin);

                        cv::createTrackbar("v max", trackbar_name, &y_vmax, 255, NULL);
                        cv::setTrackbarPos("v max", trackbar_name, y_vmax);
                }
                else if(trackbar_name.find("WHITE") != string::npos){

                        cv::createTrackbar("h min", trackbar_name, &w_hmin, 179, NULL);
                        cv::setTrackbarPos("h min", trackbar_name, w_hmin);

                        cv::createTrackbar("h max", trackbar_name, &w_hmax, 179, NULL);
                        cv::setTrackbarPos("h max", trackbar_name, w_hmax);

                        cv::createTrackbar("s min", trackbar_name, &w_smin, 255, NULL);
                        cv::setTrackbarPos("s min", trackbar_name, w_smin);

                        cv::createTrackbar("s max", trackbar_name, &w_smax, 255, NULL);
                        cv::setTrackbarPos("s max", trackbar_name, w_smax);

                        cv::createTrackbar("v min", trackbar_name, &w_vmin, 255, NULL);
                        cv::setTrackbarPos("v min", trackbar_name, w_vmin);

                        cv::createTrackbar("v max", trackbar_name, &w_vmax, 255, NULL);
                        cv::setTrackbarPos("v max", trackbar_name, w_vmax);
                }
}

void InitImgObjectforROS::setMyHSVTrackbarValue(const string &trackbar_name){

                if (trackbar_name.find("YELLOW") != string::npos) { 
                        y_hmin = cv::getTrackbarPos("h min", trackbar_name);
                        y_hmax = cv::getTrackbarPos("h max", trackbar_name);
                        y_smin = cv::getTrackbarPos("s min", trackbar_name);
                        y_smax = cv::getTrackbarPos("s max", trackbar_name);
                        y_vmin = cv::getTrackbarPos("v min", trackbar_name);
                        y_vmax = cv::getTrackbarPos("v max", trackbar_name);
                }
                else if(trackbar_name.find("WHITE") != string::npos){
                        w_hmin = cv::getTrackbarPos("h min", trackbar_name);
                        w_hmax = cv::getTrackbarPos("h max", trackbar_name);
                        w_smin = cv::getTrackbarPos("s min", trackbar_name);
                        w_smax = cv::getTrackbarPos("s max", trackbar_name);
                        w_vmin = cv::getTrackbarPos("v min", trackbar_name);
                        w_vmax = cv::getTrackbarPos("v max", trackbar_name);
                }

                nh.setParam("/"+groupName+"/lane_detection/y_hmin",y_hmin);
                nh.setParam("/"+groupName+"/lane_detection/y_hmax",y_hmax);
                nh.setParam("/"+groupName+"/lane_detection/y_smin",y_smin);
                nh.setParam("/"+groupName+"/lane_detection/y_smax",y_smax);
                nh.setParam("/"+groupName+"/lane_detection/y_vmin",y_vmin);
                nh.setParam("/"+groupName+"/lane_detection/y_vmax",y_vmax);

                nh.setParam("/"+groupName+"/lane_detection/w_hmin",w_hmin);
                nh.setParam("/"+groupName+"/lane_detection/w_hmax",w_hmax);
                nh.setParam("/"+groupName+"/lane_detection/w_smin",w_smin);
                nh.setParam("/"+groupName+"/lane_detection/w_smax",w_smax);
                nh.setParam("/"+groupName+"/lane_detection/w_vmin",w_vmin);
                nh.setParam("/"+groupName+"/lane_detection/w_vmax",w_vmax);
             
}

void InitImgObjectforROS::setColorPreocessing(lane_detect_algo::CalLane callane, cv::Mat src, cv::Mat& dst_y, cv::Mat& dst_w){
                ////*Make trackbar obj*////
                if(track_bar){
                        setMyHSVTrackbarValue(groupName+"_YELLOW_TRACKBAR");
                        setMyHSVTrackbarValue(groupName+"_WHITE_TRACKBAR");
                }

                ////*Make birdeyeview img*////
                cv::Mat bev;
                bev = src.clone();
                //cv::imshow(groupName+"bev",bev);
                if(groupName == "main"){//If you test by video, use one camera (please comment out the other camera)
                        if(bird_eye_view){
                                callane.birdEyeView_left(src,bev); //comment out by the other cam
                                if(debug) cv::imshow("bev_le",bev); //comment out by the other cam
                                //callane.birdEyeView_right(src,bev);
                                //if(debug) cv::imshow("bev_ri",bev);
                        }
                        else{
                                bev = src.clone();
                        }
                        
                }
                else if(groupName == "left"){
                        callane.birdEyeView_left(src,bev);
                        if(debug) cv::imshow("bev_le",bev);
                }
                else if(groupName == "right"){
                        callane.birdEyeView_right(src,bev);
                        if(debug) cv::imshow("bev_ri",bev);
                }
                
                
                ////*Detect yellow and white colors and make dst img to binary img by hsv value*////
                if (track_bar) {//Use trackbar. Use real-time trackbar's hsv value
                        callane.detectYHSVcolor(bev, dst_y, y_hmin, y_hmax, y_smin, y_smax, y_vmin, y_vmax);
                        callane.detectWhiteRange(bev,dst_w, w_hmin, w_hmax, w_smin, w_smax, w_vmin, w_vmax,0,0);
                        cv::imshow(groupName+"_YELLOW_TRACKBAR",dst_y);
                        cv::imshow(groupName+"_WHITE_TRACKBAR",dst_w);
                        
                }
                else {//Don't use trackbar. Use defalut value.
                        callane.detectYHSVcolor(bev, dst_y, 7, 21, 52, 151, 0, 180);
                        callane.detectWhiteRange(bev, dst_w, 0, 180, 0, 29, 179, 255,0,0);
                }       
}

void InitImgObjectforROS::setProjection(lane_detect_algo::CalLane callane, cv::Mat src, unsigned int* H_aix_Result_color){
                ////*Testing histogram*////
                cv::Mat histsrc = src.clone();
                cv::Mat dst = cv::Mat::zeros(histsrc.rows,histsrc.cols,CV_8UC1);
                callane.myProjection(histsrc,dst,H_aix_Result_color);
}

void InitImgObjectforROS::restoreImgWithLangeMerge(lane_detect_algo::CalLane callane, cv::Mat origin_size_img, cv::Mat src_y, cv::Mat src_w, cv::Mat& dst){
                ////*Restore birdeyeview img to origin view*////
                cv::Mat laneColor = src_y | src_w;
                
                dst = origin_size_img.clone();
                
                if(groupName == "left"){
                        callane.inverseBirdEyeView_left(laneColor, dst);
                }
                else if(groupName == "right"){
                        callane.inverseBirdEyeView_right(laneColor, dst); 
                }
                else if(groupName == "main"){//If you test by video, use one camera (please comment out the other camera)
                        if(bird_eye_view){
                                callane.inverseBirdEyeView_left(laneColor, dst); //comment out by the other cam
                                //callane.inverseBirdEyeView_right(laneColor, dst); 
                        }
                        else{
                                dst = laneColor.clone();
                        }        
                }
}

void InitImgObjectforROS::extractLanePoint(cv::Mat origin_src, cv::Mat lane_src){
                ////*Make lane infomation msg for translate scan data*////
                cv::Mat output_origin = origin_src.clone();
                cv::Mat pub_img = lane_src.clone();
                int coordi_count = 0;
                coordi_array.data.clear();
                coordi_array.data.push_back(10);
                for(int y = output_origin.rows-1; y>=0; y--) {
                        uchar* origin_data = output_origin.ptr<uchar>(y);
                        uchar* pub_img_data;
                        if(!gazebo){//for resizing prossesing img to webcam original image(640x320)
                                pub_img_data = pub_img.ptr<uchar>(y*0.5);//Restore resize img(0.5 -> 1))
                        }
                        else{//use gazebo topic(320x240) - None resize
                                pub_img_data = pub_img.ptr<uchar>(y); 
                        }
                        for(int x = 0; x<output_origin.cols; x++) {
                                int temp;
                                if(!gazebo){//for resizing prossesing img to webcam original image(640x320)
                                        temp = x*0.5; //Restore resize img(0.5 -> 1)
                                }
                                else{//use gazebo topic(320x240) - None resize
                                        temp = x;
                                }
                                if(pub_img_data[temp]!= (uchar)0) {
                                        coordi_count++;
                                        coordi_array.data.push_back(x);
                                        coordi_array.data.push_back(y);
                                        //origin_data[x*output_origin.channels()] = 255;
                                        origin_data[x*output_origin.channels()+1] = 25;
                                }
                        }
                }
                coordi_array.data[0] = coordi_count;

                ////*Result img marked lane*////
                // center_pt_t = cv::Point(center_pt_t.x*2,center_pt_b.y*2);
                // center_pt_b = cv::Point(center_pt_b.x*2,center_pt_b.y*2);
                // center_cali = center_cali*2;
                
                // if(center_cali != -1){
                //         cv::line(output_origin,center_pt_t,center_pt_b,cv::Scalar(100,100,200),2);
                //         cv::line(output_origin,cv::Point(center_cali,center_pt_t.y),cv::Point(center_cali,center_pt_b.y),cv::Scalar(200,100,100),2);
                // }
                cv::imshow(groupName+"_colorfulLane",output_origin);
}


void InitImgObjectforROS::setPixelGoal(double* goal, int num){
        //  goal_array.data.clear();
        //  goal_array.data.push_back(goal[num]);
        //  goal_array.data.push_back(goal[num+1]);
        //  std::cout<<"==========goal visible :"<<goal_array.data[0]<<", "<<goal_array.data[1]<<std::endl;
        }

void InitImgObjectforROS::setMySobelwithROI(cv::Mat src, double delete_row_per, const string &lane_name, cv::Mat& dst){
        cv::cvtColor(src,dst,CV_BGR2GRAY);
        cv::Mat dst_h = dst.clone();
        cv::Mat dst_v = dst.clone();
        cv::Mat element(3,3,CV_8U,cv::Scalar(1)); 
        cv::Sobel(dst_h,dst_h,dst_h.depth(),0,1);//horizontal
        cv::Sobel(dst_v,dst_v,dst_v.depth(),1,0);//vertical
        cv::Mat sobel_dilate = dst_h | dst_v;
        cv::dilate(sobel_dilate,sobel_dilate,element);
        dst = sobel_dilate;
        cv::threshold(dst, dst, 200, 255, cv::THRESH_BINARY);
        cv::imshow("sobelH",dst); 
        for(int y = 0; y<dst.rows*delete_row_per; y++){
                uchar* none_roi_data = dst.ptr<uchar>(y);
                for(int x = 0; x<dst.cols; x++){
                        if(none_roi_data[x] != (uchar)0){
                                none_roi_data[x] = (uchar)0;
                        }
                }
        }
        if(lane_name == "left"){//**set roi for left lane
                for(int y = 0; y<dst.rows; y++){
                        uchar* none_roi_data = dst.ptr<uchar>(y);
                        for(int x = dst.cols-1; x > dst.cols/2; x--){
                                if(none_roi_data[x] != (uchar)0){
                                        none_roi_data[x] = (uchar)0;
                                }
                        }
                }
                for(int y = 0; y<dst.rows; y++){
                        uchar* none_roi_data = dst.ptr<uchar>(y);
                        for(int x = 0; x < 11; x++){
                                if(none_roi_data[x] != (uchar)0){
                                        none_roi_data[x] = (uchar)0;
                                }
                        }
                }
        }
        
        if(lane_name == "right"){
                for(int y = 0; y<dst.rows; y++){
                        uchar* none_roi_data = dst.ptr<uchar>(y);
                        for(int x = 0; x < dst.cols/2; x++){
                                if(none_roi_data[x] != (uchar)0){
                                        none_roi_data[x] = (uchar)0;
                                }
                        }
                }
        }
                
}
void InitImgObjectforROS::setMyLaneBox(cv::Point t_pt, cv::Point b_pt, const string &lane_name, std::vector<cv::Point> &dst){
        if(!dst.empty() && lane_name == "left"){
                if(dst[1].x > b_pt.x) dst[1].x = b_pt.x;
                if(dst[0].y < t_pt.y) dst[0].y = t_pt.y;
        }
        else if(!dst.empty() && lane_name == "right"){
                if(dst[0].x < t_pt.x) dst[0].x = t_pt.x;
                if(dst[0].y < t_pt.y) dst[0].y = t_pt.y;
        }
}

bool InitImgObjectforROS::setMyLaneFitting(cv::Mat src_img, std::vector<cv::Point> src_pt, const string &lane_name, std::vector<cv::Point> &dst){
        if(lane_name == "left"){
                int check = 0;
                for(int y = src_pt[1].y; y > src_pt[0].y; y--) {
                        uchar* fitting_data = src_img.ptr<uchar>(y);
                        for(int x = src_pt[1].x; x > src_pt[0].x; x--) {                                
                                if(fitting_data[x]!= (uchar)0) {
                                        dst.push_back(cv::Point(x,y));
                                        if(src_pt[1].y - y < 3){
                                                if(dst[src_pt[1].y - y].x > src_img.cols/2+10){
                                                        check++;
                                                        if(check>2){
                                                                dst.clear();
                                                                dst.resize(0);
                                                                return false;
                                                        }
                                                }
                                        }
                                        break;
                                }
                        }
                }
                return true;    
        }
        if(lane_name == "right"){
                int check = 0;
                for(int y = src_pt[1].y; y>src_pt[0].y; y--) {
                        uchar* fitting_data = src_img.ptr<uchar>(y);
                        for(int x = src_pt[0].x; x<src_pt[1].x; x++) {                                
                                if(fitting_data[x]!= (uchar)0) {
                                        dst.push_back(cv::Point(x,y));
                                        if(src_pt[1].y - y < 3){
                                                if(dst[src_pt[1].y - y].x < src_img.cols/2-10){
                                                        check++;
                                                        if(check>2){
                                                                dst.clear();
                                                                dst.resize(0);
                                                                return false;
                                                        }
                                                }
                                        }
                                        break;
                                }
                        }
                }
                return true;    
        }
        if(lane_name == "dot_test"){
                int check = 0;
                for(int y = src_pt[1].y; y>src_pt[0].y; y--) {
                        uchar* fitting_data = src_img.ptr<uchar>(y);
                        for(int x = src_pt[0].x; x<src_pt[1].x; x++) {                                
                                if(fitting_data[x]!= (uchar)0) {
                                        dst.push_back(cv::Point(x,y));
                                        break;
                                }
                        }
                }
                
                return true;    
        }
        
}
 int InitImgObjectforROS::FittedLaneCheck(std::vector<cv::Point> src, const string &lane_name){
        int turn_value;
        if(lane_name == "left"){
                int tmp = -1, score = 0, sum = 0, wheel_direction = 0, steep_slope = 0;
                int steep_state1 = (src.size()/4)*1, steep_state2 = (src.size()/4)*2, steep_state3 = (src.size()/4)*3, steep_state4 = (src.size()/4)*4;
                float steep_diff1, steep_diff2, steep_diff3;
                for(int i = 0; i<src.size(); i++){
                        if(src[i].x > src[i+1].x){
                                score--;//weighted turn left
                        }
                        else{
                                score++;//weighted turn right(직선 노란차선은 보통 right 가중이 기본)
                        }
                        if(i == steep_state1){//diff<0 : 우회전, diff>0 : 좌회전 
                                steep_diff1 = atan2f((float)src[steep_state1].y - (float)src[0].y,(float)src[steep_state1].x - (float)src[0].x);
                                steep_diff1 = steep_diff1 * 180.0 / CV_PI;
                                if(steep_diff1 > 9999) steep_diff1 = 1000;
                                if(steep_diff1 < -9999) steep_diff1 = -1000;
                        }
                        // else if(i == steep_state2){
                        //         steep_diff2 = atan2f((float)src[steep_state2].y - (float)src[steep_state1].y, (float)src[steep_state2].x - (float)src[steep_state1].x);
                        //         steep_diff2 = steep_diff2 * 180.0 / CV_PI;
                        //         if(steep_diff2 > 9999) steep_diff2 = 1000;
                        //         if(steep_diff2 < -9999) steep_diff2 = -1000;
                        // }
                        // else if(i == steep_state3){
                        //         steep_diff3 = atan2f((float)src[steep_state3].y - (float)src[steep_state2].y, (float)src[steep_state3].x - (float)src[steep_state2].x);
                        //         steep_diff3 = steep_diff3 * 180.0 / CV_PI;
                        //         if(steep_diff3 > 9999) steep_diff3 = 1000;
                        //         if(steep_diff3 < -9999) steep_diff3 = -1000;
                        // }
                }
                left_doubling_vec.push_back(steep_diff1);
                // std::cout.precision(3);
                // std::cout<<"steep_state2 - steep_state1(left): " <<steep_diff1<<std::endl;
                // std::cout.precision(3);
                // std::cout<<"steep_state3 - steep_state2(left) : " <<steep_diff2<<std::endl;
                // std::cout.precision(3);
                // std::cout<<"steep_state3 - steep_state2(left) : " <<steep_diff3<<std::endl;
                // std::cout<<"avg : "<<(steep_diff1+steep_diff2+steep_diff3)/3<<std::endl;
                if(score > 0) {
//                        std::cout<<"turn right(by left lane)"<<std::endl;
                        turn_value = 1;
                        // if(abs(steep_diff1 - steep_diff2) > 10){
                        //         if(abs(steep_diff1 - ))
                        // }
                }
                else {
                        int change_check_x = -1, max_x = -9999, min_x = 9999, max_x_tmp = 0, min_x_tmp = 0, max_loop = -1, min_loop = -1;
                        int change_check_y = 0, num_y = 0, pre_num_y = 0;
                        for(int i = 0; i<src.size(); i++){
                                //** check zigzag
                                if(src[i].x > src[i+1].x){
                                        if(min_loop == 0) change_check_x++;
                                        max_x_tmp = src[i].x;
                                        max_loop = 0;
                                        if(max_x_tmp >= max_x){
                                                max_x = max_x_tmp;
                                        }
                                        min_loop = 1;
                                }
                                else{
                                        if(max_loop == 0) change_check_x++;
                                        min_loop = 0;
                                        min_x_tmp = src[i].x;
                                        if(min_x_tmp <= min_x){
                                                min_x = min_x_tmp;
                                        }
                                        max_loop = 1;
                                }
                                
                        }
                        if(change_check_x >=3 && max_x_tmp - min_x_tmp > 20) {
                                //std::cout<<"ZigZag!!~~(left)"<<std::endl;//right만 지그재그일경우 거긴 점선임
                                turn_value = 0;
                        }
                        else{
                                //std::cout<<"============turn left(by left lane)"<<std::endl;
                                turn_value = -1;
                        }
                        
                }

        }

        if(lane_name == "right"){
                int tmp = -1, score = 0, sum = 0, wheel_direction, steep_slope = 0;
                int steep_state1 = (src.size()/4)*1, steep_state2 = (src.size()/4)*2, steep_state3 = (src.size()/4)*3, steep_state4 = (src.size()/4)*4;
                float steep_diff1, steep_diff2, steep_diff3;
                for(int i = 0; i<src.size(); i++){
                        if(src[i].x >= src[i+1].x){
                                score--;//weighted turn left(직선 흰차선은 보통 left 가중이 기본)
                        }
                        else{
                                score++;//weighted turn right
                        }
                        if(i == steep_state1){//diff<0 : 우회전, diff>0 : 좌회전 
                                steep_diff1 = atan2f((float)src[steep_state1].y - (float)src[0].y,(float)src[steep_state1].x - (float)src[0].x);
                                steep_diff1 = steep_diff1 * 180.0 / CV_PI;
                                if(steep_diff1 > 999) steep_diff1 = 1000;
                                if(steep_diff1 < -999) steep_diff1 = -1000;
                        }
                        // else if(i == steep_state2){
                        //         steep_diff2 = atan2f((float)src[steep_state2].y - (float)src[steep_state1].y,(float)src[steep_state2].x - (float)src[steep_state1].x);
                        //         steep_diff2 = steep_diff2 * 180.0 / CV_PI;
                        //         if(steep_diff2 > 999) steep_diff2 = 1000;
                        //         if(steep_diff2 < -999) steep_diff2 = -1000;
                                
                        // }
                        // else if(i == steep_state3){
                        //         steep_diff3 = atan2f((float)src[steep_state4].y - (float)src[steep_state3].y,(float)src[steep_state4].x - (float)src[steep_state3].x);
                        //         steep_diff3 = steep_diff3 * 180.0 / CV_PI;
                        //         if(steep_diff3 > 999) steep_diff3 = 1000;
                        //         if(steep_diff3 < -999) steep_diff3 = -1000;
                        // }

                }
                right_doubling_vec.push_back(steep_diff1);
                // std::cout.precision(3);
                // std::cout<<"steep_state2 - steep_state1(left): " <<steep_diff1<<std::endl;
                // std::cout.precision(3);
                // std::cout<<"steep_state3 - steep_state2(left) : " <<steep_diff2<<std::endl;
                // std::cout.precision(3);
                // std::cout<<"steep_state3 - steep_state2(left) : " <<steep_diff3<<std::endl;
                // std::cout.precision(3);
                // std::cout<<"avg : "<<(steep_diff1+steep_diff2+steep_diff3)/3.0<<std::endl;
                if(score > 0) {
                        //std::cout<<"turn right"<<std::endl;
                        turn_value = 1;
                }
                else {
                        int change_check_x = -1, max_x = -9999, min_x = 9999, max_x_tmp = 0, min_x_tmp = 0, max_loop = -1, min_loop = -1;
                        int change_check_y = 0, num_y = 0, pre_num_y = 0;
                        for(int i = 0; i<src.size()/2; i++){
                                //** check zigzag
                                if(src[i].x > src[i+1].x){
                                        if(min_loop == 0 && (max_x - min_x > 20)) change_check_x++;
                                        max_x_tmp = src[i].x;
                                        max_loop = 0;
                                        if(max_x_tmp >= max_x){
                                                max_x = max_x_tmp;
                                        }
                                        min_loop = 1;
                                }
                                else{
                                        if(max_loop == 0 && (max_x - min_x > 20)) change_check_x++;
                                        min_loop = 0;
                                        min_x_tmp = src[i].x;
                                        if(min_x_tmp <= min_x){
                                                min_x = min_x_tmp;
                                        }
                                        max_loop = 1;
                                }
                                //** check dot lane
                                // pre_num_y = num_y;
                                // if(src[i].y > src[i+1].y){
                                //         num_y++;
                                // }
                                // else{
                                //         num_y--;
                                // }
                                // if((pre_num_y > num_y && abs(src[i].y - src[i+1].y)>6) ||
                                //    (pre_num_y < num_y && abs(src[i].y - src[i+1].y)>6)) {
                                //         change_check_y++;
                                // }  
                        }
                        if(change_check_x >=5 && max_x_tmp - min_x_tmp > 20) {
                                //std::cout<<"ZigZag!!~~(right)"<<std::endl;//right만 지그재그일경우 거긴 점선임
                                turn_value = 0;
                        }
                        else{
                                //std::cout<<"============turn left(by right lane)"<<std::endl;
                                turn_value = -1;
                        }
                        // if(change_check_y >= 2){
                        //         std::cout<<"dot lane!!~~(right_non_dot_check)"<<std::endl;//right만 지그재그일경우 거긴 점선임
                        //         turn_value = 3;//왼쪽의 엣지를 따라 주행? 도트들을 채우기.
                        // }
                        // else{
                        //         std::cout<<"============turn left(by right lane)"<<std::endl;
                        //         turn_value = -1;
                        // }
                }
        }

        if(lane_name == "dot_test"){
                int tmp = -1, score = 0, sum = 0, wheel_direction = 0;
                int change_check_y = 0, num_y = 0, pre_num_y = 0;
                for(int i = 0; i<src.size()/2; i++){
                        //** check dot lane
                        pre_num_y = num_y;
                        if(src[i].y > src[i+1].y){
                                num_y++;
                        }
                        else{
                                num_y--;
                        }
                        if((pre_num_y > num_y && abs(src[i].y - src[i+1].y)>6) ||
                           (pre_num_y < num_y && abs(src[i].y - src[i+1].y)>6)) {
                                change_check_y++;
                        }  
                }
                
                if(change_check_y >= 2) {
                        //std::cout<<"#########################################dot lane!!~~(right)"<<std::endl;//right만 지그재그일경우 거긴 점선임
                        //std::cout<<"dot : "<< src<<std::endl;
                        turn_value = 3;
                }
        }
        return turn_value;
 }

void InitImgObjectforROS::setMyCannywithROI(const string &lane_name, cv::Mat &dst){
        //dst = src.clone();
        cv::cvtColor(dst,dst,CV_BGR2GRAY);   
        cv::Canny(dst, dst, (dst.rows + dst.cols) / 4, (dst.rows + dst.cols) / 2);
        for(int y = 0; y<dst.rows/2; y++){
                uchar* none_roi_data = dst.ptr<uchar>(y);
                for(int x = 0; x<dst.cols; x++){
                        if(none_roi_data[x] != (uchar)0){
                                none_roi_data[x] = (uchar)0;
                        }
                }
        }
        for(int y = dst.rows/2; y<dst.rows; y++){
                uchar* none_roi_data = dst.ptr<uchar>(y);
                for(int x = dst.cols/2; x<dst.cols; x++){
                        if(none_roi_data[x] != (uchar)0){
                                none_roi_data[x] = (uchar)0;
                        }
                }
        }
        for(int y = dst.rows/2; y<dst.rows; y++){
                uchar* none_roi_data = dst.ptr<uchar>(y);
                for(int x = 0; x<11; x++){
                        if(none_roi_data[x] != (uchar)0){
                                none_roi_data[x] = (uchar)0;
                        }
                }
        }
}


int main(int argc, char **argv){
        ros::init(argc, argv, "lane_detection");
        if(!gazebo){//if you subscribe topic that published camera_image pkg 
                groupName = argv[1];
        }
        else{//if you use another img topic
                groupName = "main";//for test pointxyzrgb to mat (/camera/depth_registerd/points) please set "light" or "right"
        }
        
        ROS_INFO("strat lane detection");
        InitImgObjectforROS img_obj;
        ros::Rate loop_rate(30);
        //record flag 만들기, group node launch파일에 복구
        if(auto_record){
                if(groupName == "left")
                        video_left.open("/home/seuleee/Desktop/autorace_video_src/0717/left_record.avi",cv::VideoWriter::fourcc('X','V','I','D'),fps,cv::Size(640/2,480/2), isColor);
                else if(groupName == "right")
                        video_right.open("/home/seuleee/Desktop/autorace_video_src/0717/right_record.avi",cv::VideoWriter::fourcc('X','V','I','D'),fps,cv::Size(640/2,480/2), isColor);
                else if(groupName == "main")
                        video_main.open("/home/seuleee/Desktop/autorace_video_src/0728/main_record.avi",cv::VideoWriter::fourcc('X','V','I','D'),fps,cv::Size(640/2,480/2), isColor);
        }
        
        while(img_obj.nh.ok()) {
                img_obj.pub.publish(img_obj.coordi_array);
                img_obj.ang_vel_pub.publish(img_obj.goal_array);
               // if(img_obj.rightlane_turn_value_num == 30 && img_obj.leftlane_turn_value_num == 30){
                        img_obj.goal_pub.publish(img_obj.goal_array);
               // }
                img_obj.reset_msg_pub.publish(img_obj.reset_val);
                ros::spinOnce();
                loop_rate.sleep();

        }
        ROS_INFO("program killed!\n");
        return 0;
}









///////not used////
void InitImgObjectforROS::initMyHSVTrackbar_old(const string &trackbar_name, int *hmin, int *hmax, int *smin, int *smax, int *vmin, int *vmax){
                cv::namedWindow(trackbar_name, cv::WINDOW_AUTOSIZE);

                cv::createTrackbar("h min", trackbar_name, hmin, 179, NULL);
                cv::setTrackbarPos("h min", trackbar_name, *(hmin));

                cv::createTrackbar("h max", trackbar_name, hmax, 179, NULL);
                cv::setTrackbarPos("h max", trackbar_name, *(hmax));

                cv::createTrackbar("s min", trackbar_name, smin, 255, NULL);
                cv::setTrackbarPos("s min", trackbar_name, *(smin));

                cv::createTrackbar("s max", trackbar_name, smax, 255, NULL);
                cv::setTrackbarPos("s max", trackbar_name, *(smax));

                cv::createTrackbar("v min", trackbar_name, vmin, 255, NULL);
                cv::setTrackbarPos("v min", trackbar_name, *(vmin));

                cv::createTrackbar("v max", trackbar_name, vmax, 255, NULL);
                cv::setTrackbarPos("v max", trackbar_name, *(vmax));

}

void InitImgObjectforROS::setMyHSVTrackbarValue_old(const string &trackbar_name,int *hmin, int *hmax, int *smin, int *smax, int *vmin, int *vmax){
                *hmin = cv::getTrackbarPos("h min", trackbar_name);
                *hmax = cv::getTrackbarPos("h max", trackbar_name);
                *smin = cv::getTrackbarPos("s min", trackbar_name);
                *smax = cv::getTrackbarPos("s max", trackbar_name);
                *vmin = cv::getTrackbarPos("v min", trackbar_name);
                *vmax = cv::getTrackbarPos("v max", trackbar_name);


                 if(groupName=="left"){
                        if(trackbar_name == "LEFT_YELLOW_TRACKBAR"){
                                nh.setParam("/"+groupName+"/lane_detection/y_hmin",y_hmin);
                                nh.setParam("/"+groupName+"/lane_detection/y_hmax",y_hmax);
                                nh.setParam("/"+groupName+"/lane_detection/y_smin",y_smin);
                                nh.setParam("/"+groupName+"/lane_detection/y_smax",y_smax);
                                nh.setParam("/"+groupName+"/lane_detection/y_vmin",y_vmin);
                                nh.setParam("/"+groupName+"/lane_detection/y_vmax",y_vmax);
                        }
                        if(trackbar_name == "LEFT_WHITE_TRACKBAR"){
                                nh.setParam("/"+groupName+"/lane_detection/w_hmin",w_hmin);
                                nh.setParam("/"+groupName+"/lane_detection/w_hmax",w_hmax);
                                nh.setParam("/"+groupName+"/lane_detection/w_smin",w_smin);
                                nh.setParam("/"+groupName+"/lane_detection/w_smax",w_smax);
                                nh.setParam("/"+groupName+"/lane_detection/w_vmin",w_vmin);
                                nh.setParam("/"+groupName+"/lane_detection/w_vmax",w_vmax);
                        }
                 }
                 else if(groupName == "right"){
                        if(trackbar_name == "RIGHT_YELLOW_TRACKBAR"){
                                nh.setParam("/"+groupName+"/lane_detection/y_hmin",y_hmin);
                                nh.setParam("/"+groupName+"/lane_detection/y_hmax",y_hmax);
                                nh.setParam("/"+groupName+"/lane_detection/y_smin",y_smin);
                                nh.setParam("/"+groupName+"/lane_detection/y_smax",y_smax);
                                nh.setParam("/"+groupName+"/lane_detection/y_vmin",y_vmin);
                                nh.setParam("/"+groupName+"/lane_detection/y_vmax",y_vmax);
                        }
                        if(trackbar_name == "RIGHT_WHITE_TRACKBAR"){
                                nh.setParam("/"+groupName+"/lane_detection/w_hmin",w_hmin);
                                nh.setParam("/"+groupName+"/lane_detection/w_hmax",w_hmax);
                                nh.setParam("/"+groupName+"/lane_detection/w_smin",w_smin);
                                nh.setParam("/"+groupName+"/lane_detection/w_smax",w_smax);
                                nh.setParam("/"+groupName+"/lane_detection/w_vmin",w_vmin);
                                nh.setParam("/"+groupName+"/lane_detection/w_vmax",w_vmax);
                        }
                 }
                 else if(groupName == "main"){
                         if(trackbar_name == "YELLOW_TRACKBAR"){
                                nh.setParam("/"+groupName+"/lane_detection/y_hmin",y_hmin);
                                nh.setParam("/"+groupName+"/lane_detection/y_hmax",y_hmax);
                                nh.setParam("/"+groupName+"/lane_detection/y_smin",y_smin);
                                nh.setParam("/"+groupName+"/lane_detection/y_smax",y_smax);
                                nh.setParam("/"+groupName+"/lane_detection/y_vmin",y_vmin);
                                nh.setParam("/"+groupName+"/lane_detection/y_vmax",y_vmax);
                        }
                        if(trackbar_name == "WHITE_TRACKBAR"){
                                nh.setParam("/"+groupName+"/lane_detection/w_hmin",w_hmin);
                                nh.setParam("/"+groupName+"/lane_detection/w_hmax",w_hmax);
                                nh.setParam("/"+groupName+"/lane_detection/w_smin",w_smin);
                                nh.setParam("/"+groupName+"/lane_detection/w_smax",w_smax);
                                nh.setParam("/"+groupName+"/lane_detection/w_vmin",w_vmin);
                                nh.setParam("/"+groupName+"/lane_detection/w_vmax",w_vmax);
                        }
                 }
}

